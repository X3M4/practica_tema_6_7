package colasOOP;

public interface ColaOOP {
	public void vaciar();
	
	public boolean encolar(Object o);
	
	public Object desencolar();
	
	public Object primero();
	
	public int longitud();
	
}
