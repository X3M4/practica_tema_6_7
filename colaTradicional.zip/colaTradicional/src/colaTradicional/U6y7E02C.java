package colaTradicional;

public class  U6y7E02C {
	public static void main(String[] args) {
		ColaArrayInt cai = new ColaArrayInt();
		cai.encolar(1);
		cai.encolar(56);
		cai.encolar(5);
		cai.encolar(76);
		System.out.println(cai);
		cai.desencolar();
		cai.encolar(23);
		System.out.println(cai);
		
	}
}
