package colaTradicional;

public interface ColaInt {
	public void vaciar();
	
	public boolean encolar(int o);
	
	public int desencolar();
	
	public int primero();
	
	public int longitud();
	
}
