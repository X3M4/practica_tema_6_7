/**
 * 
 */
/**
 * @author chema
 *
 */
module colaTradicional {
}